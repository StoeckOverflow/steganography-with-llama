from src.models import DynamicPOE

if __name__ == "__main__":
    dpoe = DynamicPOE(disable_tqdm=True)
    dpoe.hide_interface()
